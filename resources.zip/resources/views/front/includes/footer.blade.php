<div class="footer">
    <div class="contaier ">
        <div class="row ">
            <div class=" footer-item1 ">
                <h2>الإدارة العامة للمعاهد الأزهرية</h2>
                <hr class="footer-hr1">
                <p> العنوان : فلسطين-غزة-شارع جمال عبد الناصر-الثلاثيني سابقاً <i class="fas fa-map-marker-alt "></i></p>
                <p> <span class="mail">azhariinst@gmail.com </span>: البريد الالكترونى الرسمى <i class="fas fa-envelope "></i></p>
                <p>0 8 2 6 3 4 0 9 3/هاتف <i class="fas fa-phone "></i></p>
                <p>0 8 2 6 3 4 0 9 3/فاكس <i class="fas fa-fax "></i></p>
                <div class="iconr">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                    <i class="fab fa-whatsapp"></i>
                </div>
            </div>
            <div class=" footer-item2 ">
                <h2>فروعنا</h2>
                <hr class="footer-hr">
                <p>معهد الأزهر الديني فرع خان يونس <i class="fas fa-map-marker-alt "></i></p>
                <p>جورة اللوت-بجـــوار المحاكم</p>
                <p>082068550/هاتف <i class="fas fa-phone "></i></p>
                <p>082068550/فاكس <i class="fas fa-fax "></i></p>
                <h2>فروعنا</h2>
                <hr class="footer-hr">
                <p>معهد الأزهر الديني فرع شمال غزة <i class="fas fa-map-marker-alt "></i></p>
                <p> بيت لاهيا-الشارع العام-دوار حبوب-بجوار جامعة غزة</p>
                <p>082474033/هاتف <i class="fas fa-phone "></i></p>
                <p>082474033/فاكس <i class="fas fa-fax "></i></p>
            </div>
            <div class=" footer-item3 ">
                <img src="{{asset('assets/front/img/تنزيل.png')}} " alt=" ">
                <p>الإدارة العامة للمعاهد الأزهرية في فلسطين</p>
                <p>AL AZHAR INST. GENERAL ADMINST-PALESTINE</p>
                <img class="sv" src="{{asset('assets/front/img/azharinist.svg')}}" alt="">
            </div>
        </div>
    </div>
</div>
