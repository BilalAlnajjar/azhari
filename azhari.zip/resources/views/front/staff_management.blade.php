@extends('layouts.front')

@section('content')
    <div class="channel">
        <div class="container">
            <div class="row">
                <span class="channel-title">الرئيسية/إدارة شؤون الموظفين</span>
                <hr style="
                width: 110px;
                margin-left: 730px;
                color: rgba(6, 30, 57, 1);
                border: 1px solid #000;
                margin-top: -5px;
            ">
            </div>
        </div>
    </div>

    <form action="{{route('login')}}" method="post" class="mb-5">
        @csrf
    <div class="login">
        <div class="container">
            <div class="row">
                <div class="page-login">
                    <h1 class="login-title">تسجيل الدخول</h1>
                    <input class="form-control login-input" name="email" type="text" placeholder="Uesrname">
                    <input class="form-control login-input" name="password" type="text" value="password">
                    <a class="login-a" href="{{route('password.request')}}">...هل نسيت كلمة المرور</a>
                    <br>
                    <button type="submit"  style="border: none" class="login-a1">تسجيل الدخول</button>
                </div>
            </div>
        </div>
    </div>
    </form>

@endsection
