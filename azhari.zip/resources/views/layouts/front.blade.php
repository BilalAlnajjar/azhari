<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@600&display=swap" rel="stylesheet">
    <!-- bootstrap CSS only -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">


{{--    <!-- Vendor CSS Files -->--}}
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
{{--    <link href="{{asset('assets/front/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">--}}
{{--    <link href="{{asset('assets/front/vendor/icofont/icofont.min.css')}}" rel="stylesheet">--}}
{{--    <link href="{{asset('assets/front/vendor/boxicons/css/boxicons.min.css')}}" rel="stylesheet">--}}
{{--    <link href="{{asset('assets/front/vendor/owl.carousel/assets/owl.carousel.min.css')}}" rel="stylesheet">--}}
{{--    <link href="{{asset('assets/front/vendor/venobox/venobox.css')}}" rel="stylesheet">--}}
{{--    <link href="{{asset('assets/front/vendor/aos/aos.css')}}" rel="stylesheet">--}}

    <!-- CSS only -->
    <link rel="stylesheet" href="{{asset('assets/front/css/normalize.css')}}">
    <!-- <link rel="stylesheet" href="{{asset('assets/front/css/all.css')}}" /> -->
    <link rel="stylesheet" href="{{asset('assets/front/css/min.css')}}">

    <link rel="stylesheet" href="{{asset('assets/front/css/responsive.css')}}">
    <!-- Responsive-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>الرئيسية </title>
</head>

@include('front.includes.header')

<div class="d-flex flex-row-reverse">

<!-- Start side -->
@include('front.includes.side')
<!-- End side -->

<!-- star content -->

<div class="w-80 mx-auto">
    @yield('content')
    <!-- end content -->
</div>
</div>


<!-- End  Footer-->
@include('front.includes.footer')
<!-- End  Footer-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
{{--<script src="{{asset('assets/front/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>--}}
{{--<script src="{{asset('assets/front/vendor/jquery.easing/jquery.easing.min.js')}}"></script>--}}
{{--<script src="{{asset('assets/front/vendor/php-email-form/validate.js')}}"></script>--}}
{{--<script src="{{asset('assets/front/vendor/owl.carousel/owl.carousel.min.js')}}"></script>--}}
{{--<script src="{{asset('assets/front/vendor/isotope-layout/isotope.pkgd.min.js')}}"></script>--}}
{{--<script src="{{asset('assets/front/vendor/venobox/venobox.min.js')}}"></script>--}}
{{--<script src="{{asset('assets/front/vendor/aos/aos.js')}}"></script>--}}
<!-- JavaScript Bundle with Popper -->
<script src="http://localhost:8000/assets/front/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js " integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM " crossorigin="anonymous "></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js " integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM " crossorigin="anonymous "></script>
<!-- End  conect-->
<script>
    var i = 0; // Start point
    var images = [];
    var time = 1000;
    // Image List
    @isset($sliders)
    @foreach($sliders as $slider )
    images[{{$loop->iteration-1}}] = '{{$slider->path_image}}';

        @endforeach
            @endisset
    // Change Image
    function changeImg(){
        document.slide.src = images[i];
        if(i < images.length - 1){
            i++;
        } else {
            i = 0;
        }
        // setTimeout("changeImg()",time);
    }
    window.onload = changeImg;
</script>
@yield('scripts')
<!-- JavaScript Bundle with Popper -->
</html>
